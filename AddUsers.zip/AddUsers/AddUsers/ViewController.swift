//
//  ViewController.swift
//  AddUsers
//
//  Created by Apple on 31/10/19.
//  Copyright © 2019 appzoo. All rights reserved.
//

import UIKit
import SDWebImage

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var myLabel: UILabel!
}

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    let reuseIdentifier = "cell"
    /*var items = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48"]*/
    var sessionArray = [String]()
    var useridArray = [String]()
    var nameArray = [String]()
    var profileArray = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.storeValidaion()
    }
    
    // MARK: - UICollectionViewDataSource protocol
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.nameArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! MyCollectionViewCell
        
        let url = self.profileArray[indexPath.item]
        cell.profileImage.sd_setImage(with: URL(string: url), placeholderImage: UIImage(named: "placeholder.png"))
        cell.myLabel.text = self.nameArray[indexPath.item]
        cell.backgroundColor = UIColor.cyan
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("You selected cell #\(indexPath.item)!")
    }
    
    @IBAction func addClick(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "listviewcontroller") as! ListViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .fullScreen
        let navigationController = UINavigationController(rootViewController: vc)
        self.present(navigationController, animated: true, completion: nil)
    }
    
    @IBAction func clearClick(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "session")
        self.useridArray.removeAll()
        self.profileArray.removeAll()
        self.nameArray.removeAll()
        self.collectionView.reloadData()
    }
    
    
    //MARK: Store Validation and CollectionView Reloading
    func storeValidaion(){
        // Retrive Array Values
        if let data = UserDefaults.standard.value(forKey:"session") as? Data {
            let sessionData = try? PropertyListDecoder().decode(Array<Datum>.self, from: data)
            print("ARRAY VALUES: \(sessionData!)")
            
            for person in sessionData! {
                print(person.userid!)
                self.useridArray.append(person.userid!)
                self.nameArray.append(person.firstname!)
                self.profileArray.append(person.profileimage!)
                print(useridArray)
                print(profileArray)
                self.collectionView.reloadData()
            }
        }
    }
}

