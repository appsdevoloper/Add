//
//  ListViewController.swift
//  AddUsers
//
//  Created by Apple on 31/10/19.
//  Copyright © 2019 appzoo. All rights reserved.
//

import UIKit

// MARK: - Welcome
struct Root: Codable {
    let status: Bool
    let data: [Datum]
}

// MARK: - Datum
struct Datum: Codable, Hashable {
    let userid, firstname, designation: String?
    let profileimage: String?
}

enum UserDefaultsKeys: String {
    case jobCategory
}

class MyCustomCell: UITableViewCell {
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var nameCellLabel: UILabel!
    @IBOutlet weak var subtitleCellLabel: UILabel!
}

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var studentsData = [Datum]()
    //var sessionData = [Datum]()
    var sessionData = Set<Datum>()
    
    let cellReuseIdentifier = "cell"
    @IBOutlet var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        self.tableView.rowHeight = 62
        self.loadJSON()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.studentsData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:MyCustomCell = self.tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier) as! MyCustomCell
        let item = self.studentsData[indexPath.row]
        cell.nameCellLabel.text = item.firstname
        cell.subtitleCellLabel.text = item.designation
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = self.studentsData[indexPath.row]
        if let cell = tableView.cellForRow(at: indexPath) {
            if cell.accessoryType == .checkmark {
                cell.accessoryType = .none

                // UnCheckmark cell JSON data Remove from array
                self.sessionData.remove(item)
                print(sessionData)

            } else {
                cell.accessoryType = .checkmark
                
                // Checkmark selected data Insert into array
                self.sessionData.insert(item)
                print(sessionData)
            }
        }
    }
    
    // MARK: JSON Data Load
    
    func loadJSON() {
        let urlPath = "https://api.myjson.com/bins/kny70"
        let url = NSURL(string: urlPath)
        let session = URLSession.shared
        let task = session.dataTask(with: url! as URL) { data, response, error in
            guard data != nil && error == nil else {
                print(error!.localizedDescription)
                return
            }
            do {
                let decoder = try JSONDecoder().decode(Root.self,  from: data!)
                let status = decoder.status
                
                if status == true {
                    self.studentsData = decoder.data
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                } else {
                    
                }
            } catch { print(error) }
        }
        task.resume()
    }
    
    @IBAction func saveAction(_ sender: Any) {
        
        for person in sessionData where (person.userid != nil) {
            // Do something
            print(person.userid!)
            UserDefaults.standard.set(try? PropertyListEncoder().encode(sessionData), forKey:"session")
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func cancelAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
